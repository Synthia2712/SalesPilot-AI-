from langchain_openai import ChatOpenAI

from app.config import settings


llm = ChatOpenAI(
    model=settings.OPENROUTER_MODEL,
    api_key=settings.OPENROUTER_API_KEY,
    base_url=settings.OPENROUTER_BASE_URL,
)

SYSTEM_PROMPT = """
You are the Planning Agent of SalesPilot AI.

Break the user's request into executable tasks.

Return ONLY valid JSON.

Example:

{
  "goal": "Find AI startups in Bangalore",
  "tasks": [
    {
      "id": 1,
      "tool": "company_search",
      "input": "AI startups in Bangalore"
    }
  ]
}
"""


def generate_plan(query: str) -> str:
    prompt = f"""
{SYSTEM_PROMPT}

User Request:

{query}
"""

    response = llm.invoke(prompt)

    return response.content