from app.tools.registry import TOOLS


def execute_tasks(tasks):

    results = []

    for task in tasks:

        tool = TOOLS.get(task["tool"])

        if tool:

            output = tool.run(task["input"])

            results.append(
                {
                    "tool": task["tool"],
                    "output": output
                }
            )

    return results