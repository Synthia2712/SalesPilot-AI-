from fastapi import FastAPI

from app.api.planner import router as planner_router
from app.api.company import router as company_router

app = FastAPI(
    title="SalesPilot AI",
    description="Autonomous Sales Intelligence Platform",
    version="1.0.0",
)

app.include_router(planner_router)
app.include_router(company_router)


@app.get("/")
def home():
    return {
        "message": "🚀 SalesPilot AI is running!"
    }